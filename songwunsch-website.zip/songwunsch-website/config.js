// Trage hier die Projekt-URL und den anon/public Key aus deinem Supabase-Projekt ein.
// Diese Werte dürfen im Browser stehen. NIEMALS den service_role Key hier eintragen.
window.SUPABASE_URL = "DEINE_SUPABASE_PROJECT_URL";
window.SUPABASE_ANON_KEY = "DEIN_SUPABASE_ANON_PUBLIC_KEY";